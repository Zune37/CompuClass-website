import { useEffect, useState, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { ArrowRight, Menu, X } from 'lucide-react';
import { Link, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();
const domain = 'https://compuclass.co.za';
const servicesHref = `${import.meta.env.BASE_URL}#services`;
const cvServicesHref = `${import.meta.env.BASE_URL}training-development#cv-services`;
const whatsappHref = (message: string) => `https://wa.me/27849230178?text=${encodeURIComponent(message)}`;
const navigation = [
  { href: '/', label: 'Home' },
  { href: '/organisational-solutions', label: 'Organisational solutions' },
  { href: '/dwca', label: 'DWCA' },
  { href: '/training-development', label: 'Training & development' },
  { href: '/spaces', label: 'CompuClass Spaces' },
  { href: '/about', label: 'About' },
  { href: '/contact', label: 'Contact' },
];
const pageMeta: Record<string, { title: string; description: string }> = {
  '/': { title: 'Services for Digital Capability & Careers | CompuClass', description: 'Explore organisational digital capability, practical digital skills training, CV and career services, and professional portfolio support from CompuClass Solutions.' },
  '/organisational-solutions': { title: 'Organisational Digital Capability Solutions | CompuClass', description: 'Explore workforce digital-skills gap identification, practical development, AI literacy and assessment-informed reporting with CompuClass Solutions.' },
  '/dwca': { title: 'Digital Workplace Capability Assessment (DWCA) | CompuClass', description: 'Learn about the Digital Workplace Capability Assessment, an assessment-to-report service and instrument currently under development and piloting.' },
  '/training-development': { title: 'Digital Skills, CV & Career Services | CompuClass', description: 'Explore practical digital skills training, CV packages, career services, and professional portfolio and employability support.' },
  '/spaces': { title: 'CompuClass Spaces | Venue Partnerships for Digital Skills Training', description: 'Learn about CompuClass Spaces, a developing venue partnership initiative seeking suitable pilot spaces in the Eastern Cape and Johannesburg.' },
  '/about': { title: 'About CompuClass Solutions | Simplified Computer Knowledge', description: 'Discover the purpose and practical approach behind CompuClass Solutions, a digital capability and workforce development partner.' },
  '/contact': { title: 'Contact CompuClass Solutions | WhatsApp or Enquiry Form', description: 'Contact CompuClass Solutions on WhatsApp, by phone or email, or use the general enquiry form.' },
};

function Seo({ path }: { path: string }) {
  useEffect(() => {
    const meta = pageMeta[path] ?? pageMeta['/'];
    document.title = meta.title;
    const set = (selector: string, value: string, attr = 'content') => {
      const element = document.querySelector(selector);
      if (element) element.setAttribute(attr, value);
    };
    set('meta[name="description"]', meta.description);
    set('meta[property="og:title"]', meta.title);
    set('meta[property="og:description"]', meta.description);
    set('meta[property="og:url"]', `${domain}${path}`);
    set('meta[name="twitter:title"]', meta.title);
    set('meta[name="twitter:description"]', meta.description);
    set('link[rel="canonical"]', `${domain}${path}`, 'href');
  }, [path]);
  return null;
}

function Brand() {
  return <Link href="/" className="brand" aria-label="CompuClass Solutions home" data-testid="link-brand-home">
    <img
      className="brand-logo"
      src={`${import.meta.env.BASE_URL}compuclass-logo.png`}
      alt="CompuClass Learning Hub — Simplified Computer Knowledge"
      width="641"
      height="508"
    />
  </Link>;
}

function WhatsAppButton({ message, label, className = 'button button-primary', testId }: { message: string; label: string; className?: string; testId?: string }) {
  return <a href={whatsappHref(message)} target="_blank" rel="noopener noreferrer" className={className} data-testid={testId}>
    {label} <ArrowRight size={16} aria-hidden="true" />
  </a>;
}

function Header() {
  const [path] = useLocation();
  const [open, setOpen] = useState(false);
  useEffect(() => setOpen(false), [path]);
  return <header className="topbar">
    <div className="container nav-inner">
      <Brand />
      <nav className="nav-links" aria-label="Main navigation">
        <a href={servicesHref} data-testid="link-nav-services">Services</a>
        {navigation.slice(1).map((item) => <Link key={item.href} href={item.href} aria-current={path === item.href ? 'page' : undefined} data-testid={`link-nav-${item.href.slice(1)}`}>{item.label}</Link>)}
        <a href={whatsappHref('Hello CompuClass, I would like to discuss your services.')} className="nav-cta" target="_blank" rel="noopener noreferrer" data-testid="link-nav-whatsapp">WhatsApp us <ArrowRight size={14} aria-hidden="true" /></a>
      </nav>
      <button className="menu-toggle" type="button" aria-label={open ? 'Close navigation menu' : 'Open navigation menu'} aria-expanded={open} onClick={() => setOpen(!open)} data-testid="button-menu-toggle">
        {open ? <X size={22} /> : <Menu size={22} />}
      </button>
    </div>
    {open && <nav className="mobile-nav" aria-label="Mobile navigation">
      <a href={servicesHref} data-testid="link-mobile-services">Services</a>
      {navigation.slice(1).map((item) => <Link key={item.href} href={item.href} aria-current={path === item.href ? 'page' : undefined}>{item.label}</Link>)}
      <a href={whatsappHref('Hello CompuClass, I would like to discuss your services.')} target="_blank" rel="noopener noreferrer" className="mobile-nav-cta" data-testid="link-mobile-whatsapp">WhatsApp us <ArrowRight size={14} /></a>
    </nav>}
  </header>;
}

function Footer() {
  return <footer className="footer">
    <div className="container">
      <div className="footer-top">
        <div className="footer-brand"><Brand /><p>Practical digital capability and workforce development. Simplified Computer Knowledge.</p></div>
        <nav className="footer-links" aria-label="Footer navigation">
          <a href={servicesHref}>Services</a>
          {navigation.map(item => <Link key={item.href} href={item.href}>{item.label}</Link>)}
          <a href="mailto:info@compuclass.co.za">info@compuclass.co.za</a>
          <a href="tel:+27849230178" data-testid="link-footer-phone">084 923 0178</a>
          <a href={whatsappHref('Hello CompuClass, I would like to discuss your services.')} target="_blank" rel="noopener noreferrer" data-testid="link-footer-whatsapp">WhatsApp</a>
          <a href="https://compuclass.co.za" target="_blank" rel="noopener noreferrer">compuclass.co.za</a>
        </nav>
      </div>
      <div className="footer-bottom"><span>© {new Date().getFullYear()} CompuClass Solutions</span><span>Simplified Computer Knowledge.</span></div>
    </div>
  </footer>;
}

function Shell({ children }: { children: ReactNode }) {
  return <div className="site-shell"><AnchorScroll /><Header />{children}<Footer /></div>;
}

function AnchorScroll() {
  const [path] = useLocation();
  useEffect(() => {
    const id = decodeURIComponent(window.location.hash.slice(1));
    if (!id) return;
    const frame = window.requestAnimationFrame(() => document.getElementById(id)?.scrollIntoView({ block: 'start', behavior: 'instant' }));
    return () => window.cancelAnimationFrame(frame);
  }, [path]);
  return null;
}

function Eyebrow({ children }: { children: ReactNode }) {
  return <div className="eyebrow">{children}</div>;
}

function Home() {
  return <Shell>
    <Seo path="/" />
    <main>
      <section className="hero">
        <div className="container">
          <Eyebrow>Digital capability · Workforce development</Eyebrow>
          <h1>BUILDING DIGITALLY<br /><span>CAPABLE WORKFORCES</span></h1>
          <p className="hero-copy">We help organisations assess digital capability, identify workforce skills gaps and develop practical pathways towards greater digital confidence, productivity and AI readiness.</p>
          <div className="hero-actions">
            <WhatsAppButton message="Hello CompuClass, I would like to discuss my organisation's digital capability and workforce development needs." label="Discuss your needs on WhatsApp" testId="link-home-whatsapp" />
            <Link href="/dwca" className="button button-outline" data-testid="link-home-dwca">Explore the DWCA <ArrowRight size={16} /></Link>
          </div>
          <Link href="/contact" className="hero-form-link" data-testid="link-home-enquiry-form">Prefer a form? Use the general enquiry form.</Link>
          <div className="hero-note">Practical capability for the way work happens</div>
        </div>
      </section>
      <div className="sequence"><div className="container sequence-inner"><span className="sequence-label">A clear path to capability</span><div className="sequence-steps"><span>ASSESS</span><b>→</b><span>UNDERSTAND</span><b>→</b><span>DEVELOP</span><b>→</b><span>MEASURE.</span></div></div></div>
      <section className="section">
        <div className="container split">
          <div className="copy-block"><div className="editorial-number">01 / Start with understanding</div><h2>Digital confidence is built in the flow of work.</h2><p>Every organisation has its own people, tools and day-to-day realities. We help you understand current capability first, so development can respond to what teams actually need.</p><Link className="link-arrow" href="/organisational-solutions">Explore organisational solutions <ArrowRight size={16} /></Link></div>
          <div className="capability-panel"><div className="panel-label">Capability, made practical</div><div className="cap-list">
            <div className="cap-row"><span>Digital foundations</span><span>Assess</span></div><div className="cap-row"><span>Workplace productivity</span><span>Understand</span></div><div className="cap-row"><span>Digital safety</span><span>Develop</span></div><div className="cap-row"><span>Responsible AI readiness</span><span>Prepare</span></div>
          </div></div>
        </div>
      </section>
      <section className="section ink-section">
        <div className="container">
          <div className="section-head"><div><Eyebrow>Digital Workplace Capability Assessment</Eyebrow><h2>See the capability picture more clearly.</h2></div><p>A structured assessment-to-report approach designed to help organisations understand strengths, development needs and useful next steps.</p></div>
          <div className="process-grid">
            <article className="process-item"><span className="process-num">01 / ASSESS</span><h3>Gather a useful picture</h3><p>Online questionnaires and facilitated practical tasks explore digital confidence in context.</p></article>
            <article className="process-item"><span className="process-num">02 / UNDERSTAND</span><h3>Make sense of needs</h3><p>Review patterns across digital foundations, productivity, safety and AI readiness.</p></article>
            <article className="process-item"><span className="process-num">03 / DEVELOP</span><h3>Focus development</h3><p>Use findings to shape practical development pathways for teams and departments.</p></article>
            <article className="process-item"><span className="process-num">04 / MEASURE</span><h3>Track the next steps</h3><p>Department-level recommendations help guide where to focus and what to revisit.</p></article>
          </div>
          <p style={{ margin: '24px 0 0', color: '#aaa49b', fontSize: 12 }}>The DWCA service and instrument are under development and piloting.</p>
          <Link href="/dwca" className="link-arrow">Understand the DWCA <ArrowRight size={16} /></Link>
        </div>
      </section>
      <section className="section">
        <div className="container split">
          <div className="capability-panel"><div className="panel-label">Practical training topics</div><div className="cap-list">
            {['Smartphone and computer literacy','Email, internet and file management','Word, Excel and digital communication','Cybersecurity awareness and responsible AI'].map(x => <div className="cap-row" key={x}><span>{x}</span><span>Learn</span></div>)}
          </div></div>
          <div className="copy-block"><div className="editorial-number">02 / Build everyday skills</div><h2>Useful skills. Real workplace context.</h2><p>Practical digital skills training can help people approach everyday tasks with greater confidence—from managing files and communicating online to using AI responsibly.</p><Link className="link-arrow" href="/training-development">Explore training and development <ArrowRight size={16} /></Link></div>
        </div>
      </section>
      <section id="services" className="section services-section" data-testid="section-home-services">
        <div className="container">
          <div className="section-head"><div><Eyebrow>Services</Eyebrow><h2>Practical support for capability and employability.</h2></div><p>Explore organisational digital capability, practical skills training, CV and career services, and employability support.</p></div>
          <div className="service-grid">
            <article className="service-card">
              <span className="service-kicker">01 / ORGANISATIONAL SOLUTIONS</span>
              <h3>Build digital capability at work.</h3>
              <p>Digital Workplace Capability Assessment (under development and piloting), workforce digital-skills gap identification, practical skills development, AI literacy and assessment-informed reporting.</p>
              <div className="service-card-actions">
                <WhatsAppButton message="Hello CompuClass, I would like to discuss organisational digital capability services." label="Discuss organisational services" className="service-cta" testId="link-services-organisational-whatsapp" />
                <Link href="/organisational-solutions" className="service-detail-link">Explore organisational solutions <ArrowRight size={14} /></Link>
              </div>
            </article>
            <article className="service-card">
              <span className="service-kicker">02 / DIGITAL SKILLS TRAINING</span>
              <h3>Practical skills for everyday work.</h3>
              <p>Basic computer and smartphone literacy, email, internet, file management, Word, Excel, digital safety, professional communication and AI skills.</p>
              <div className="service-card-actions">
                <WhatsAppButton message="Hello CompuClass, I would like to discuss practical digital skills training." label="Ask about digital skills training" className="service-cta" testId="link-services-training-whatsapp" />
                <Link href="/training-development" className="service-detail-link">Explore training and development <ArrowRight size={14} /></Link>
              </div>
            </article>
            <article className="service-card">
              <span className="service-kicker">03 / CV & CAREER SERVICES</span>
              <h3>Clear CV service options.</h3>
              <ul className="service-price-list" aria-label="CV service prices">
                <li><span>Basic CV</span><strong>R150</strong></li>
                <li><span>Standard CV <span className="popular-tag">Most popular</span></span><strong>R250</strong></li>
                <li><span>Professional CV</span><strong>R400</strong></li>
                <li><span>Cover letter add-on</span><strong>R100</strong></li>
                <li><span>24-hour express add-on</span><strong>R100</strong></li>
              </ul>
              <div className="service-card-actions">
                <WhatsAppButton message="Hello CompuClass, I would like to enquire about your CV and career services." label="Enquire about CV services" className="service-cta" testId="link-services-cv-whatsapp" />
                <a href={cvServicesHref} className="service-detail-link">View CV service details <ArrowRight size={14} /></a>
              </div>
            </article>
            <article className="service-card">
              <span className="service-kicker">04 / EMPLOYABILITY SUPPORT</span>
              <h3>Portfolios and employability support.</h3>
              <p>Enquire with us about professional portfolios and employability support to discuss a suitable package.</p>
              <div className="service-card-actions">
                <WhatsAppButton message="Hello CompuClass, I would like to enquire about a suitable professional portfolio or employability support package." label="Enquire about a suitable package" className="service-cta" testId="link-services-employability-whatsapp" />
              </div>
            </article>
          </div>
        </div>
      </section>
      <section className="section-tight ink-section spaces-promo">
        <div className="container split">
          <div><Eyebrow>CompuClass Spaces</Eyebrow><h2>Space to Learn. Skills to Grow.</h2><p>A developing venue partnership initiative for suitable spaces that can host practical digital-skills training.</p></div>
          <div className="spaces-promo-action"><Link href="/spaces" className="button button-primary" data-testid="link-home-spaces">Explore CompuClass Spaces <ArrowRight size={16} /></Link></div>
        </div>
      </section>
      <section className="section-tight" style={{ background: '#edeae3' }}>
        <div className="container split">
          <div className="copy-block"><div className="editorial-number">A practical partner</div><h2>Built around people, not assumptions.</h2><p>CompuClass Solutions works with public-sector organisations, corporate teams and education partners to make digital capability development clearer and more relevant.</p><Link className="link-arrow" href="/about">About CompuClass <ArrowRight size={16} /></Link></div>
          <div><Eyebrow>Start a conversation</Eyebrow><h2 style={{ fontSize: 'clamp(32px,4vw,48px)', letterSpacing: '-2px', lineHeight: 1.05, margin: '18px 0 22px', fontWeight: 500 }}>What would digital confidence make possible for your teams?</h2><WhatsAppButton message="Hello CompuClass, I would like to discuss digital capability for my organisation." label="Discuss on WhatsApp" className="button button-primary" testId="link-home-bottom-whatsapp" /><Link href="/contact" className="text-form-link">Use the general enquiry form</Link></div>
        </div>
      </section>
    </main>
  </Shell>;
}

function PageIntro({ label, title, description, path }: { label: string; title: string; description: string; path: string }) {
  return <><Seo path={path} /><section className="page-hero"><div className="container"><Eyebrow>{label}</Eyebrow><h1>{title}</h1><p>{description}</p></div></section></>;
}

function OrganisationalSolutions() {
  return <Shell><main><PageIntro path="/organisational-solutions" label="Organisational solutions" title="Understand capability. Develop with purpose." description="A practical way to understand digital capability across your organisation, identify workforce skills gaps and shape development that responds to real needs." />
    <section className="page-content"><div className="container content-grid">
      <aside><div className="side-label">A clearer starting point</div><div className="notice" style={{ marginTop: 18 }}><strong>Start with the work.</strong><br />Understand people’s current experience, the tasks they need to do and the support that can help them move forward.</div><Link className="link-arrow" href="/spaces" data-testid="link-organisational-spaces">Explore CompuClass Spaces <ArrowRight size={16} /></Link></aside>
      <div className="content-copy"><h2>From a skills-gap question to a practical pathway.</h2><p>Digital capability is not one single skill. It spans the everyday foundations people use to access information, communicate, work safely and make use of digital tools. Our approach helps organisations explore that picture and decide where development can be most useful.</p>
        <div className="topic-grid">
          <article className="topic"><span className="topic-index">01</span><h3>Assess capability</h3><p>Use assessment activities to explore confidence and practical capability in context.</p></article>
          <article className="topic"><span className="topic-index">02</span><h3>Understand skills gaps</h3><p>Look at development needs across teams and departments, rather than relying on assumptions.</p></article>
          <article className="topic"><span className="topic-index">03</span><h3>Develop pathways</h3><p>Shape practical learning and workforce development around the needs identified.</p></article>
          <article className="topic"><span className="topic-index">04</span><h3>Review progress</h3><p>Return to capability over time and consider what has changed and what comes next.</p></article>
        </div>
        <p style={{ marginTop: 27 }}>This work can include the Digital Workplace Capability Assessment and practical digital skills training, depending on the organisation’s requirements.</p>
        <div className="service-scope" data-testid="organisational-service-scope">
          <h3>Organisational services include</h3>
          <ul>
            <li>Digital Workplace Capability Assessment (under development and piloting)</li>
            <li>Workforce digital-skills gap identification</li>
            <li>Practical skills development and AI literacy</li>
            <li>Assessment-informed reporting</li>
          </ul>
        </div>
        <div className="cta-stack">
          <WhatsAppButton message="Hello CompuClass, I would like to discuss organisational digital-skills gaps, practical development, AI literacy or assessment-informed reporting." label="Discuss organisational solutions on WhatsApp" testId="link-organisational-whatsapp" />
          <Link href="/contact" className="button button-outline">Use the general enquiry form</Link>
        </div>
      </div>
    </div></section></main></Shell>;
}

function Dwca() {
  return <Shell><main><PageIntro path="/dwca" label="Assessment & insight" title="Digital Workplace Capability Assessment" description="The DWCA is a service and instrument in development, designed to help organisations build a clearer picture of workplace digital capability and possible next steps." />
    <section className="page-content"><div className="container content-grid">
      <aside><div className="side-label">Important status</div><div className="notice" style={{ marginTop: 18 }}><strong>The DWCA is under development and piloting.</strong><br />It is not presented as an accredited or validated assessment, or as an instrument already used in government contracts.</div></aside>
      <div className="content-copy"><h2>An assessment-to-report process.</h2><p>The intended service brings together online questionnaires and facilitated practical tasks. Findings can help an organisation discuss digital foundations, workplace productivity, digital safety and readiness to approach AI responsibly.</p>
        <div className="process-grid" style={{ background: '#1d1b19', padding: '0 22px', margin: '26px 0' }}>
          <article className="process-item"><span className="process-num">01</span><h3>Questionnaires</h3><p>Online questions provide a structured view of reported confidence and experience.</p></article>
          <article className="process-item"><span className="process-num">02</span><h3>Practical tasks</h3><p>Facilitated activities explore everyday digital tasks in context.</p></article>
          <article className="process-item"><span className="process-num">03</span><h3>Assessment report</h3><p>Information is brought together to support a clearer discussion of capability.</p></article>
          <article className="process-item"><span className="process-num">04</span><h3>Recommendations</h3><p>Department-level recommendations can help inform development priorities.</p></article>
        </div>
        <h2>Areas the assessment is designed to explore</h2><div className="feature-list">
          {['Digital foundations','Workplace productivity','Digital safety','AI readiness'].map((x,i)=><div className="feature" key={x}><span><strong>{x}</strong>{[' — access and everyday digital confidence',' — using tools to support day-to-day work',' — awareness of safer digital practices',' — considering AI use responsibly'][i]}</span></div>)}
        </div>
        <p>Assessment scope and process may evolve as development and piloting continue. To discuss the current status or explore whether the approach may suit your organisation, please get in touch.</p>
        <div className="cta-stack">
          <WhatsAppButton message="Hello CompuClass, I would like to ask about the DWCA and its current development and piloting status." label="Ask about the DWCA on WhatsApp" testId="link-dwca-whatsapp" />
          <Link href="/contact" className="button button-outline">Use the general enquiry form</Link>
        </div>
      </div>
    </div></section></main></Shell>;
}

function Training() {
  const topics = [
    ['01', 'Smartphone and computer literacy', 'Build familiarity with devices, settings and everyday digital tasks.'],
    ['02', 'Email', 'Use email with clarity and confidence.'],
    ['03', 'Internet skills', 'Find, evaluate and use online information for everyday work.'],
    ['04', 'File management', 'Create, organise, locate and share digital files.'],
    ['05', 'Word and Excel', 'Develop practical document and spreadsheet skills.'],
    ['06', 'Digital safety', 'Recognise everyday risks and practice safer digital habits.'],
    ['07', 'Professional communication', 'Use digital channels for clear, professional workplace communication.'],
    ['08', 'AI skills and responsible use', 'Explore thoughtful, responsible ways to approach AI tools.'],
  ];
  return <Shell><main><PageIntro path="/training-development" label="Training & development" title="Digital skills for everyday work." description="Practical learning that helps people build confidence with the devices, applications and digital practices they encounter in daily work." />
    <section className="page-content"><div className="container content-grid"><aside><div className="side-label">Practical by design</div><div className="notice" style={{ marginTop: 18 }}>Learning starts with the task at hand. Training can be discussed in relation to your organisation’s priorities and the capability needs you have identified.</div><Link className="link-arrow" href="/organisational-solutions">Explore organisational solutions <ArrowRight size={16} /></Link><Link className="link-arrow" href="/spaces" data-testid="link-training-spaces">Venue partnerships with CompuClass Spaces <ArrowRight size={16} /></Link></aside>
      <div className="content-copy"><h2>Build everyday digital confidence, one useful skill at a time.</h2><p>Digital skills training can support smartphone and computer literacy, workplace productivity, communication and safer online habits. It can also introduce responsible AI use as organisations consider how these tools fit into work.</p>
      <div className="topic-grid">{topics.map(([n,title,copy])=><article className="topic" key={n}><span className="topic-index">{n}</span><h3>{title}</h3><p>{copy}</p></article>)}</div>
      <p style={{ marginTop: 28 }}>The training conversation can begin with the tasks people need to do and the areas where additional support may help.</p>
      <div className="cta-stack">
        <WhatsAppButton message="Hello CompuClass, I would like to discuss practical digital skills training." label="Talk about training on WhatsApp" testId="link-training-whatsapp" />
        <Link href="/contact" className="button button-outline">Use the general enquiry form</Link>
      </div></div>
    </div></section>
    <section id="cv-services" className="section cv-section" data-testid="section-cv-services"><div className="container">
      <div className="section-head"><div><Eyebrow>CV & career services</Eyebrow><h2>CV options and add-ons.</h2></div><p>Prices are shown for the listed services. Choose a package to discuss the next steps with CompuClass.</p></div>
      <div className="cv-package-grid">
        <article className="cv-package"><h3>Basic CV</h3><p className="cv-price">R150</p></article>
        <article className="cv-package cv-package-popular"><span className="popular-tag">Most popular</span><h3>Standard CV</h3><p className="cv-price">R250</p></article>
        <article className="cv-package"><h3>Professional CV</h3><p className="cv-price">R400</p></article>
      </div>
      <div className="cv-addons">
        <div><span>Cover letter add-on</span><strong>R100</strong></div>
        <div><span>24-hour express add-on</span><strong>R100</strong></div>
      </div>
      <div className="cta-stack">
        <WhatsAppButton message="Hello CompuClass, I would like to enquire about your CV packages and add-ons." label="Enquire about CV services on WhatsApp" testId="link-cv-whatsapp" />
        <Link href="/contact" className="button button-outline">Use the general enquiry form</Link>
      </div>
    </div></section>
    <section className="section-tight employability-section"><div className="container split">
      <div className="copy-block"><Eyebrow>Professional portfolios & employability support</Eyebrow><h2>Enquire about a suitable package.</h2><p>Contact CompuClass to discuss professional portfolios and employability support and enquire about a suitable package.</p></div>
      <div className="cta-stack">
        <WhatsAppButton message="Hello CompuClass, I would like to enquire about a suitable professional portfolio or employability support package." label="Enquire about a suitable package" testId="link-employability-whatsapp" />
        <Link href="/contact" className="button button-outline">Use the general enquiry form</Link>
      </div>
    </div></section>
  </main></Shell>;
}

function SpacesEnquiryForm() {
  const [preparedHref, setPreparedHref] = useState('');
  const [status, setStatus] = useState('');

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    if (String(data.get('website') || '').trim()) return;
    const fields = {
      name: String(data.get('name') || '').trim(),
      venue: String(data.get('venue') || '').trim(),
      area: String(data.get('area') || '').trim(),
      equipment: String(data.get('equipment') || '').trim() || 'Not specified',
      capacity: String(data.get('capacity') || '').trim() || 'Not specified',
      availability: String(data.get('availability') || '').trim() || 'Not specified',
      contact: String(data.get('contact') || '').trim(),
      message: String(data.get('message') || '').trim() || 'No additional message',
    };
    const message = [
      'Hello CompuClass, I would like to enquire about a CompuClass Spaces venue partnership.',
      `Name: ${fields.name}`,
      `Organisation or venue: ${fields.venue}`,
      `Town/area: ${fields.area}`,
      `Available equipment: ${fields.equipment}`,
      `Venue capacity: ${fields.capacity}`,
      `Availability: ${fields.availability}`,
      `Contact details: ${fields.contact}`,
      `Message: ${fields.message}`,
    ].join('\n');
    const href = whatsappHref(message);
    setPreparedHref(href);
    setStatus('Your details are ready to review in WhatsApp. Check the message and tap Send to complete your enquiry.');
    window.open(href, '_blank', 'noopener,noreferrer');
  }

  return <form id="space-partner-form" className="form-panel spaces-form" onSubmit={submit}>
    <h2>Venue enquiry</h2>
    <p className="form-intro">Share a few venue details. We’ll prepare a WhatsApp message for you to review and send.</p>
    <div className="form-grid">
      <div className="field"><label htmlFor="spaces-name">Your name <span aria-hidden="true">*</span></label><input id="spaces-name" name="name" autoComplete="name" required maxLength={100} data-testid="input-spaces-name" /></div>
      <div className="field"><label htmlFor="spaces-venue">Organisation or venue name <span aria-hidden="true">*</span></label><input id="spaces-venue" name="venue" autoComplete="organization" required maxLength={140} data-testid="input-spaces-venue" /></div>
      <div className="field"><label htmlFor="spaces-area">Town or area <span aria-hidden="true">*</span></label><input id="spaces-area" name="area" autoComplete="address-level2" required maxLength={120} data-testid="input-spaces-area" /></div>
      <div className="field"><label htmlFor="spaces-capacity">Venue capacity</label><input id="spaces-capacity" name="capacity" type="number" min="1" step="1" inputMode="numeric" data-testid="input-spaces-capacity" /></div>
      <div className="field field-full"><label htmlFor="spaces-equipment">Available equipment</label><textarea id="spaces-equipment" name="equipment" rows={3} maxLength={800} data-testid="input-spaces-equipment" /></div>
      <div className="field field-full"><label htmlFor="spaces-availability">Availability for training sessions</label><textarea id="spaces-availability" name="availability" rows={3} maxLength={800} data-testid="input-spaces-availability" /></div>
      <div className="field field-full"><label htmlFor="spaces-contact">Contact email or phone <span aria-hidden="true">*</span></label><input id="spaces-contact" name="contact" autoComplete="off" required maxLength={180} data-testid="input-spaces-contact" /></div>
      <div className="field field-full"><label htmlFor="spaces-message">Short message</label><textarea id="spaces-message" name="message" rows={4} maxLength={1500} data-testid="input-spaces-message" /></div>
      <div className="honeypot" aria-hidden="true"><label htmlFor="spaces-website">Leave this field empty</label><input id="spaces-website" name="website" tabIndex={-1} autoComplete="off" /></div>
    </div>
    <div className="form-foot"><p>Required fields are marked *. Your details are placed in a WhatsApp message; review and send it to complete your enquiry.</p><button type="submit" className="button button-primary" data-testid="button-submit-spaces">Prepare WhatsApp enquiry <ArrowRight size={16} /></button></div>
    {status && <div className="form-status success" role="status" aria-live="polite" data-testid="status-spaces">
      {status} {preparedHref && <a href={preparedHref} target="_blank" rel="noopener noreferrer" className="prepared-message-link">Open the prepared WhatsApp message <ArrowRight size={14} /></a>}
    </div>}
  </form>;
}

function Spaces() {
  return <Shell><main>
    <PageIntro
      path="/spaces"
      label="CompuClass Spaces · Venue partnerships"
      title="Space to Learn. Skills to Grow."
      description="We're building a network of accessible, computer-equipped spaces where people and organisations can participate in practical digital-skills training. Through partnerships with existing venues, CompuClass aims to make learning opportunities more accessible without requiring every training session to take place in a dedicated training facility."
    />
    <section className="section spaces-partner">
      <div className="container split">
        <div className="copy-block">
          <Eyebrow>Partner with CompuClass</Eyebrow>
          <h2>Make room for practical learning.</h2>
          <p>Internet cafés, venue owners, property owners, training centres and others with suitable spaces can register their interest in making a venue available for practical digital-skills training sessions.</p>
          <p>CompuClass Spaces is a developing partnership initiative. Venue suitability, availability and any pilot arrangement are discussed with each potential partner.</p>
        </div>
        <div className="spaces-audience">
          <div className="panel-label">Potential venue partners</div>
          <ul>
            <li>Internet cafés</li>
            <li>Computer-equipped venues</li>
            <li>Training centres</li>
            <li>Property owners with suitable spaces</li>
          </ul>
        </div>
      </div>
    </section>
    <section className="section spaces-criteria">
      <div className="container">
        <div className="section-head"><div><Eyebrow>Venue suitability</Eyebrow><h2>What makes a suitable space?</h2></div><p>These are preferred suitability criteria to guide a conversation. They are not mandatory certifications.</p></div>
        <ul className="spaces-criteria-list">
          <li>Working computers or suitable digital devices</li>
          <li>Reliable electricity and, ideally, internet access</li>
          <li>Seating and a suitable environment for facilitated learning</li>
          <li>Convenient and accessible location</li>
          <li>Availability for agreed training sessions</li>
        </ul>
      </div>
    </section>
    <section className="section ink-section spaces-process">
      <div className="container">
        <div className="section-head"><div><Eyebrow>How it works</Eyebrow><h2>A clear path to explore a partnership.</h2></div><p>Each step is discussed with potential venue partners before any training sessions are arranged.</p></div>
        <div className="process-grid">
          <article className="process-item"><span className="process-num">01 / REGISTER</span><h3>Register your interest</h3><p>Share a few details about you and the venue.</p></article>
          <article className="process-item"><span className="process-num">02 / DISCUSS</span><h3>Talk through the venue</h3><p>Discuss equipment, location and availability with CompuClass.</p></article>
          <article className="process-item"><span className="process-num">03 / ASSESS</span><h3>Agree a pilot arrangement</h3><p>Consider suitability and agree on any pilot arrangement before proceeding.</p></article>
          <article className="process-item"><span className="process-num">04 / COORDINATE</span><h3>Coordinate suitable sessions</h3><p>Coordinate training sessions once an agreement is in place.</p></article>
        </div>
      </div>
    </section>
    <section className="section spaces-pilot">
      <div className="container split">
        <div className="copy-block"><Eyebrow>Our pilot approach</Eyebrow><h2>Developing a practical partnership model.</h2></div>
        <div className="spaces-pilot-copy">
          <p>We are seeking suitable pilot venues in both the Eastern Cape and Johannesburg. The initial focus is on partnerships that allow us to test the model without taking on unnecessary fixed rental and equipment costs.</p>
          <p>CompuClass Spaces is not yet an operational venue-booking marketplace. Registering interest does not guarantee bookings, income or occupancy; venue suitability and any pilot arrangement will be discussed and agreed with CompuClass.</p>
        </div>
      </div>
    </section>
    <section id="space-enquiry" className="section spaces-enquiry">
      <div className="container">
        <div className="section-head"><div><Eyebrow>Register your interest</Eyebrow><h2>Have a Space That Could Support Learning?</h2></div><p>Tell us about your venue, its equipment and when it may be available for training sessions.</p></div>
        <div className="spaces-form-layout">
          <aside className="spaces-cta-panel">
            <h3>Start a venue enquiry.</h3>
            <p>Complete the short form and review your details in WhatsApp before sending.</p>
            <a href="#space-partner-form" className="button button-primary" data-testid="link-spaces-partner">Partner With CompuClass <ArrowRight size={16} /></a>
            <WhatsAppButton message="Hello CompuClass, I would like to enquire about the CompuClass Spaces venue partnership initiative." label="Ask about a venue on WhatsApp" className="spaces-direct-whatsapp" testId="link-spaces-whatsapp" />
          </aside>
          <SpacesEnquiryForm />
        </div>
      </div>
    </section>
  </main></Shell>;
}

function About() {
  return <Shell><main><PageIntro path="/about" label="About CompuClass" title="Simplified Computer Knowledge." description="CompuClass Solutions exists to help make digital capability clearer, more practical and more accessible in the places people work and learn." />
    <section className="page-content"><div className="container split">
      <div className="copy-block"><div className="editorial-number">Purpose</div><h2>Build confidence that people can use.</h2><p>Digital tools are part of everyday work, but access to tools alone does not ensure confidence. CompuClass Solutions focuses on understanding capability and supporting practical development, so people can engage with digital work with greater clarity.</p></div>
      <div className="copy-block"><div className="editorial-number">Approach</div><h2>Listen. Understand. Develop.</h2><p>We work with public-sector organisations, corporate teams and education partners. The starting point is the organisation’s context: the work people do, the capabilities they need and the areas where development may be helpful.</p><p>From there, assessment and training conversations can help shape practical next steps, including responsible preparation for AI.</p></div>
    </div></section>
    <section className="section ink-section"><div className="container split"><div className="copy-block"><Eyebrow>How we think about capability</Eyebrow><h2>Useful, grounded, and developed with care.</h2></div><div><div className="cap-row"><span>Begin with everyday digital work</span><span>01</span></div><div className="cap-row"><span>Understand needs before prescribing learning</span><span>02</span></div><div className="cap-row"><span>Build practical confidence and responsible habits</span><span>03</span></div></div></div></section>
     <section className="section-tight"><div className="container split"><div className="copy-block"><h2>Interested in a practical next step?</h2><p>Tell us a little about your organisation and what you would like to explore.</p></div><div className="cta-stack"><WhatsAppButton message="Hello CompuClass, I would like to discuss practical digital capability and workforce development." label="Start a WhatsApp conversation" testId="link-about-whatsapp" /><Link href="/contact" className="button button-outline">Use the general enquiry form</Link></div></div></section>
  </main></Shell>;
}

type EnquiryData = { name: string; organisation: string; email: string; type: string; message: string; website: string };
function ContactForm() {
  const [status, setStatus] = useState<{ kind: 'success' | 'error'; message: string } | null>(null);
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    if (String(data.get('website') || '').trim()) {
      setStatus({ kind: 'success', message: 'Thank you. Your enquiry has been prepared.' });
      form.reset();
      return;
    }
    const fields: EnquiryData = {
      name: String(data.get('name') || ''),
      organisation: String(data.get('organisation') || ''),
      email: String(data.get('email') || ''),
      type: String(data.get('type') || ''),
      message: String(data.get('message') || ''),
      website: '',
    };
    const subject = encodeURIComponent(`CompuClass enquiry: ${fields.type}`);
    const body = encodeURIComponent(`Name: ${fields.name}\nOrganisation: ${fields.organisation}\nEmail: ${fields.email}\nEnquiry type: ${fields.type}\n\nMessage:\n${fields.message}`);
    setStatus({ kind: 'success', message: 'Your email app should open with your enquiry addressed to info@compuclass.co.za. Please send the message from your email app to complete your enquiry.' });
    try {
      window.location.href = `mailto:info@compuclass.co.za?subject=${subject}&body=${body}`;
      form.reset();
    } catch {
      setStatus({ kind: 'error', message: 'We could not open your email app. Please email info@compuclass.co.za directly.' });
    }
  }
  return <form className="form-panel" onSubmit={submit} noValidate={false}>
    <h2>Send an enquiry</h2><p className="form-intro">Share a little context and your default email app will open with a message addressed to our team.</p>
    <div className="form-grid">
      <div className="field"><label htmlFor="name">Name <span aria-hidden="true">*</span></label><input id="name" name="name" autoComplete="name" required maxLength={100} data-testid="input-name" /></div>
      <div className="field"><label htmlFor="organisation">Organisation <span aria-hidden="true">*</span></label><input id="organisation" name="organisation" autoComplete="organization" required maxLength={140} data-testid="input-organisation" /></div>
      <div className="field"><label htmlFor="email">Email address <span aria-hidden="true">*</span></label><input id="email" name="email" type="email" autoComplete="email" required maxLength={160} data-testid="input-email" /></div>
      <div className="field"><label htmlFor="type">Enquiry type <span aria-hidden="true">*</span></label><select id="type" name="type" defaultValue="" required data-testid="select-enquiry-type"><option value="" disabled>Select an enquiry type</option><option>Organisational solutions</option><option>Digital Workplace Capability Assessment</option><option>Training and development</option><option>General enquiry</option></select></div>
      <div className="field field-full"><label htmlFor="message">Message <span aria-hidden="true">*</span></label><textarea id="message" name="message" required minLength={10} maxLength={4000} data-testid="input-message" /></div>
      <div className="honeypot" aria-hidden="true"><label htmlFor="website">Leave this field empty</label><input id="website" name="website" tabIndex={-1} autoComplete="off" /></div>
    </div>
    <div className="form-foot"><p>Fields marked * are required. This form opens your email app; it does not send data to a server.</p><button type="submit" className="button button-primary" data-testid="button-submit-enquiry">Prepare enquiry <ArrowRight size={16} /></button></div>
    {status && <div className={`form-status ${status.kind}`} role="status" aria-live="polite" data-testid={`status-${status.kind}`}>{status.message}</div>}
  </form>;
}

function Contact() {
  return <Shell><main><PageIntro path="/contact" label="Contact" title="Start with a conversation." description="Tell us what your organisation is working towards. We can explore digital capability, the DWCA or practical skills development together." />
    <section className="page-content"><div className="container contact-layout">
      <aside className="contact-card"><Eyebrow>Get in touch</Eyebrow><h2>We’re ready to hear what you need.</h2><p>Choose an enquiry type in the form and share as much context as you are comfortable with.</p>
        <WhatsAppButton message="Hello CompuClass, I would like to enquire about your services." label="Chat with CompuClass on WhatsApp" className="button button-primary contact-whatsapp" testId="link-contact-whatsapp" />
        <a className="contact-detail" href="mailto:info@compuclass.co.za"><small>Email</small>info@compuclass.co.za</a>
        <a className="contact-detail" href="tel:+27849230178" data-testid="link-contact-phone"><small>Call</small>084 923 0178</a>
        <a className="contact-detail" href="https://compuclass.co.za" target="_blank" rel="noopener noreferrer"><small>Website</small>compuclass.co.za <ArrowRight size={13} /></a>
      </aside>
      <ContactForm />
    </div></section></main></Shell>;
}

function Router() {
  const [location] = useLocation();
  return <RoutedErrorBoundary><Switch>
    <Route path="/" component={Home} />
    <Route path="/organisational-solutions" component={OrganisationalSolutions} />
    <Route path="/dwca" component={Dwca} />
    <Route path="/training-development" component={Training} />
    <Route path="/spaces" component={Spaces} />
    <Route path="/about" component={About} />
    <Route path="/contact" component={Contact} />
    <Route component={NotFound} />
  </Switch><span hidden>{location}</span></RoutedErrorBoundary>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;
