# CompuClass Solutions website source export

This archive contains the CompuClass Solutions website source, all seven client-side routes (including `/spaces`), its logo and public assets, the pnpm workspace manifests/lockfile, and the shared workspace source needed by the app. It intentionally excludes installed dependencies, build outputs/caches, Replit artifact metadata, Git history, uploaded source duplicates not used by the site, and private environment files.

## Build for static hosting

Requirements: Node.js 22 or newer and pnpm. From this folder, install the website and its workspace dependency, then build:

```sh
pnpm install --frozen-lockfile --filter '@workspace/compuclass-solutions...'
PORT=5173 BASE_PATH=/ pnpm --filter @workspace/compuclass-solutions run build
```

The static publish directory is `artifacts/compuclass-solutions/dist/public`. Set `BASE_PATH=/` when serving the site from the host's root domain. The Vite config reads `PORT` and `BASE_PATH` directly from the process environment; `.env.example` is a reference only, so define these variables in the host's build settings or use the command above. No API key, database, or server-side secret is required for the website build.

Because the site uses client-side routes, configure the static host to serve `/index.html` for unknown paths (a single-page-app fallback) so direct visits and refreshes on routes such as `/spaces` work. Host-specific setup may vary.

The contact form opens the visitor's email app; the CompuClass Spaces form prepares a WhatsApp message for the visitor to review and send. These forms do not save submissions on a server.
